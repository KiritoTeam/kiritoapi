const package = require("./package.json");

module.exports = {
  api_version: package.version,
}

//git config --global user.email "felipebragabr123@gmail.com"
//git config --global user.name "CroneGamesPlays"
//dev cmds: shell -> (git add .), (git commit -m "last commit"), (git push);
//dev pack: npm adduser
//dev pack: npm publish